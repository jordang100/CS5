GlowScript 2.6 VPython
from visual import *


scene.bind('keydown', keydown_fun)
scene.background = .1*vector(1,1,1)
scene.width = 720
scene.height = 720
scene.userzoom = False
scene.userspin = False
scene.lights = []
scene.title = '<h1 style="border:2px rgb(0,0,0)">Ball</h1>'
scene.caption = 'Score: 0\nHigh Score: 0\n <Controls>\nW - Up\nA - Left\nS - Down\nD - Right\nR - Restart\n'

# +++ start of object-creation functions...
# these functions create "container" objects, called "compounds"

# +++ start of OBJECT_CREATION section

# the ground - a box (vpython's rectangular solid)
# http://www.glowscript.org/docs/GlowScriptDocs/box.html

# two walls, also boxes
wallA = box(pos=vector(0,-24,0), axis=vector(1,0,0), size=vector(48.3,.3,1))
wallB = box(pos=vector(-24,0,0), axis=vector(0,1,0), size=vector(48.3,.3,1))
wallC = box(pos=vector(24,0,0),  axis=vector(0,1,0), size=vector(48.3,.3,1))
wallD = box(pos=vector(0,24,0),  axis=vector(1,0,0), size=vector(48.3,.3,1))

score = 0
highScore = 0

gridLines = []

# create horizontal lines
for x in range(-7,8):
    convx = x*3
    gridlineN = box(pos=vector(0,convx,0), axis=vector(1,0,0), size=vector(48,.1,.3))
# create vertical lines
for x in range(-7,8):
    convx = x*3
    gridlineN = box(pos=vector(convx,0,0), axis=vector(0,1,0), size=vector(48,.1,.3))

# create origin
origin = sphere(size=0.1*vector(1,1,1))

# a ball that we will be able to control
ball = sphere(size=2*vector(1,1,1),targ = vector(0,0,0),inMove = False)
ball.dir = vector(0,0,0)

emi = local_light(pos=vector(0,0,0),color=color.green,size=0.3*vector(1,1,1))
emi2 = local_light(pos=vector(0,0,0),color=color.blue,size=0.3*vector(1,1,1))

point = sphere(size=vector(1,1,1),color=color.white)
spawn()

# +++ end of OBJECT_CREATION section


# +++ start of ANIMATION section

# other constants
RATE = 10                # the number of times the while loop runs each second
scene.autoscale = False  # avoids changing the view automatically
dummyVar = 0
amt = 3   # "strength" of the keypress's velocity changes

while True:    # this is the "event loop": each loop is one step in time, dt
    
    rate(RATE) # maximum number of times per second the while loop runs 

    # +++ start of PHYSICS UPDATES - update all positions here, every time step
    
    # +++ start of COLLISIONS - check for collisions + do the "right" thing
    
    if ball.pos.x == point.pos.x and ball.pos.y == point.pos.y:
        spawn()
        score += 1
        if score > highScore:
            highScore = score
        
        if score == 15:
            print('Now following: Ball')
            scene.camera.follow(ball)            
        if score == 25:
            print('Speed increased.')
            RATE += 10
        if score == 30:
            print('Controls inverted.')
            ball.pos = vector(0,0,0)
            ball.dir = vector(0,0,0)
            amt = -3
        if score == 50:
            print('Speed increased.')
            RATE += 10
        if score == 60:
            print('Take a breather...')
            ball.pos = vector(0,0,0)
            ball.dir = vector(0,0,0)
        if score == 75:
            print('Speed increased.')
            RATE += 15
        if score == 90:
            print('Mini-mode.')
            emi.pos.visible = False
            ball.size = 0.6*vector(1,1,1)
            point.size = 0.6*vector(1,1,1)
        if score == 100:
            print('Speed increased.')
            RATE += 25
        if score == 101:
            print('You win! Keep playing for a high score.')
            print('From here, speed will increase slightly with each ball.')
        if score > 101:
            RATE += 5
        
        scene.caption = 'Score: ' + str(score) + '\nHigh Score: ' + str(highScore)
            
    if -24 <= ball.pos.x <= 24 and -24 <= ball.pos.y <= 24:
        dummyVar = 0
    else:
        score = 0
        gameOver()

    # +++ end of COLLISIONS
    
    emi.pos = ball.pos
    emi2.pos = point.pos
    curTime = 0
    # Move the ball
    if ball.inMove:
        ball.pos = ball.targ
        ball.inMove = False
    else:
        ball.pos = ball.pos + 3*ball.dir
    

    # +++ end of PHYSICS UPDATES - be sure new objects are updated appropriately!

    
    
    
# +++ start of EVENT_HANDLING section - separate functions for
#                                keypresses and mouse clicks...

def keydown_fun(event):
    """ function called with each key pressed """
        
    key = chr(event.which)
    
    if key in 'R':
        restart()

    if key in 'A' and abs(ball.dir.x) != 1:
        newpos = ball.pos + vector(-amt,0,0)
        moveBall(newpos)
    if key in 'S' and abs(ball.dir.y) != 1:
        newpos = ball.pos + vector(0,-amt,0)
        moveBall(newpos)
    if key in "D" and abs(ball.dir.x) != 1:
        newpos = ball.pos + vector(amt,0,0)
        moveBall(newpos)
    if key in 'W' and abs(ball.dir.y) != 1:
        newpos = ball.pos + vector(0,amt,0)
        moveBall(newpos)


    
    
# +++ end of EVENT_HANDLING section

# +++ other functions can go here...
def gameOver():
    RATE = 30
    ball.dir = vector(0,0,0)
    print('Game Over! Press R to restart.')
    score = 0
    scene.caption = 'Score: ' + str(score) + '\nHigh Score: ' + str(highScore)
    
def restart():
    RATE = 30
    spawn()
    ball.pos = vector(0,0,0)
    ball.dir = vector(0,0,0)
    score = 0
    scene.caption = 'Score: ' + str(score) + '\nHigh Score: ' + str(highScore)

def moveBall(newpos):
    if not ball.inMove:
        ball.targ = newpos
        
        diffx = ball.pos.x - ball.targ.x
        diffy = ball.pos.y - ball.targ.y
        if diffx > 0:
            ball.dir = vector(-1,0,0)
        if diffx < 0:
            ball.dir = vector(1,0,0)
        if diffy > 0:
            ball.dir = vector(0,-1,0)
        if diffy < 0:
            ball.dir = vector(0,1,0)
            
def rngL():
    return int(random()*14)-7

def spawn():
    randLoc = ball.pos
    while randLoc == ball.pos:
        randLoc = vector(rngL()*3,rngL()*3,0)
    point.pos = randLoc

    
def randint( low, hi ):
    """ implements Python's randint using the random() function 
        returns an int from low to hi _inclusive_ (so, it's not 100% Pythonic)
    """
    if hi < low:  low, hi = hi, low  # swap if out of order!
    LEN = int(hi)-int(low)+1   # get the span and add 1
    randvalue = LEN*random()   # get a random value
    return int(randvalue)      # return the integer part of it